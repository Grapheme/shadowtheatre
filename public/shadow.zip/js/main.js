var $i = 1;
$('.app-button').each(function(){
	if($i == 10) $i = 0;
	$(this).attr('data-number', $i);
	$i++;
});


function appButtonClick(e) {
	$(this).css('background-image','url(img/button-act.png)');
	typeThis($(this).attr('data-number'));
} 

$('.app-button').bind( "touchstart", appButtonClick);
//$('.app-button').bind( "click", appButtonClick);

$('.app-button').bind( "touchend", function(e){
    $(this).css('background-image','url(img/button.png)');
});

$('.final-click').bind('touchstart',function(){
	gotoFinal();
});

function gotoFinal() {
	$('.app.shadow').fadeOut(function(){
		$('.app.final').fadeIn();
	});
}

function gotoShadow() {
	$('<img/>').attr('src', 'img/deluxe1.png').load(function() {
		$('.main').fadeOut(function(){
			$('.shadow').fadeIn();
		});
	});
}

function gotoFinal() {
	$('.shadow').fadeOut();
	$('.final').fadeIn();
}

var pass = "";
var pass_allow = true;

function typeThis(number) {
	if(pass_allow) {
		if ( $('.closed')[0] ) {
			$('.closed').last().next().html(number).addClass('closed');
		} else {
			$('.typing-div span').first().html(number);
			$('.typing-div span').first().addClass('closed');
		}
		pass += number;
		if(pass.length == 4) {
			if(pass == '1234') {
				gotoShadow();
			} else {
				pass_allow = false;
				clearType();
				pass = "";
			}
		}
	}
}

function clearType() {
	$('.app-button').effect("shake", {times: 3, distance: 10}, function(){
		$('.closed').html('*').removeClass('closed');
		setTimeout(function() { pass_allow = true; }, 300);
	});
}

$(document).bind('touchmove', false);